'use client'
import { useState } from 'react'
import Nav from '@/components/Nav'

const BRANCHES = [
  { id: 'vitrine', label: 'Site vitrine', desc: 'Pages services, présentation', icon: '🏪', color: 'blue' },
  { id: 'ecommerce', label: 'E-commerce', desc: 'Fiches produits, catégories', icon: '🛒', color: 'green' },
  { id: 'catalogue', label: 'Catalogue', desc: 'Descriptions, PDF, listes', icon: '📚', color: 'amber' },
]

const TONES = [
  { value: 'expert', label: 'Expert & rassurant' },
  { value: 'accessible', label: 'Accessible & chaleureux' },
  { value: 'premium', label: 'Premium & sobre' },
  { value: 'direct', label: 'Direct & percutant' },
]

const WORD_COUNTS = [
  { value: '800', label: '800 mots — minimal' },
  { value: '1200', label: '1200 mots — standard' },
  { value: '1500', label: '1500 mots — enrichi' },
  { value: '2000', label: '2000 mots — complet' },
]

function Field({ label, required, hint, children }) {
  return (
    <div className="field">
      <label className="label">
        {label} {required && <span className="required">*</span>}
      </label>
      {children}
      {hint && <span style={{ fontSize: '11px', color: 'var(--text-muted)', marginTop: '4px' }}>{hint}</span>}
    </div>
  )
}

export default function Dashboard() {
  const [branch, setBranch] = useState('vitrine')
  const [form, setForm] = useState({
    company: '', url: '', city: '', sector: '', description: '',
    keyword_main: '', keywords_sec: '', intent: '', h1: '',
    word_count: '1200', tone: 'expert', lang: 'fr', extra: '',
    product_name: '', product_price: '', product_ref: '',
    cat_product: '', cat_ref: '', cat_specs: '',
  })
  const [loading, setLoading] = useState(false)
  const [alert, setAlert] = useState(null)
  const [showPayload, setShowPayload] = useState(false)

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }))
  const handle = k => e => set(k, e.target.value)

  const secondaryTags = form.keywords_sec.split(',').map(s => s.trim()).filter(Boolean)

  function buildPayload() {
    const base = {
      branch,
      company: form.company, url: form.url, city: form.city,
      sector: form.sector, description: form.description,
      keyword_main: form.keyword_main, keywords_secondary: form.keywords_sec,
      intent: form.intent, h1: form.h1, word_count: form.word_count,
      tone: form.tone, language: form.lang, extra_instructions: form.extra,
    }
    if (branch === 'ecommerce') Object.assign(base, {
      product_name: form.product_name, product_price: form.product_price, product_ref: form.product_ref,
    })
    if (branch === 'catalogue') Object.assign(base, {
      cat_product: form.cat_product, cat_ref: form.cat_ref, cat_specs: form.cat_specs,
    })
    return base
  }

  async function launch() {
    if (!form.company || !form.url || !form.keyword_main) {
      setAlert({ type: 'error', msg: 'Remplissez les champs obligatoires : entreprise, URL et mot-clé principal.' })
      return
    }
    setLoading(true)
    setAlert(null)
    try {
      const res = await fetch('/api/launch', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(buildPayload()),
      })
      const data = await res.json()
      if (res.ok) {
        setAlert({ type: 'success', msg: `Automatisation lancée avec succès pour "${form.company}" !` })
      } else {
        setAlert({ type: 'error', msg: data.error || 'Erreur lors du lancement.' })
      }
    } catch {
      setAlert({ type: 'error', msg: 'Erreur réseau. Vérifiez votre connexion.' })
    } finally {
      setLoading(false)
    }
  }

  const s = { // styles helpers
    grid2: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' },
    grid3: { display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '12px' },
    section: { marginBottom: '12px' },
  }

  return (
    <div style={{ display: 'flex', minHeight: '100vh' }}>
      <Nav />
      <main style={{ flex: 1, marginLeft: '220px', padding: '32px', maxWidth: '860px' }}>
        <div className="fade-in">
          <div style={{ marginBottom: '28px' }}>
            <h1 style={{ fontSize: '22px', fontWeight: '600', marginBottom: '4px' }}>Nouveau lancement</h1>
            <p style={{ color: 'var(--text-secondary)', fontSize: '13px' }}>
              Renseignez les informations client pour déclencher l'automatisation Make.
            </p>
          </div>

          {/* Branch selector */}
          <div className="card" style={s.section}>
            <div className="section-title">Branche de génération</div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: '10px' }}>
              {BRANCHES.map(b => (
                <button
                  key={b.id}
                  onClick={() => setBranch(b.id)}
                  style={{
                    padding: '14px', borderRadius: '10px', textAlign: 'left',
                    border: branch === b.id ? `1.5px solid var(--${b.color === 'blue' ? 'blue' : b.color === 'green' ? 'green' : 'amber'})` : '1px solid var(--border)',
                    background: branch === b.id ? `var(--${b.color === 'blue' ? 'blue' : b.color === 'green' ? 'green' : 'amber'}-soft)` : 'var(--bg)',
                    cursor: 'pointer', transition: 'all 0.15s',
                  }}
                >
                  <div style={{ fontSize: '20px', marginBottom: '6px' }}>{b.icon}</div>
                  <div style={{ fontSize: '13px', fontWeight: '500', color: 'var(--text-primary)', marginBottom: '2px' }}>{b.label}</div>
                  <div style={{ fontSize: '12px', color: 'var(--text-secondary)' }}>{b.desc}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Client info */}
          <div className="card" style={s.section}>
            <div className="section-title">Informations client</div>
            <div style={{ ...s.grid2, marginBottom: '12px' }}>
              <Field label="Nom de l'entreprise" required>
                <input value={form.company} onChange={handle('company')} placeholder="ex : Pierre Carrelage" />
              </Field>
              <Field label="URL cible" required hint={form.url ? '→ ' + (form.url.startsWith('http') ? form.url : 'https://' + form.url) : ''}>
                <input value={form.url} onChange={handle('url')} placeholder="ex : pierrecarrelage.com/pose-carrelage" />
              </Field>
            </div>
            <div style={{ ...s.grid2, marginBottom: '12px' }}>
              <Field label="Ville / zone géographique">
                <input value={form.city} onChange={handle('city')} placeholder="ex : Pau, Morlaàs, Orthez" />
              </Field>
              <Field label="Secteur d'activité">
                <input value={form.sector} onChange={handle('sector')} placeholder="ex : Carrelage, Plomberie..." />
              </Field>
            </div>
            <Field label="Description courte">
              <textarea value={form.description} onChange={handle('description')} placeholder="Ancienneté, spécialités, valeurs de l'entreprise..." style={{ minHeight: '70px' }} />
            </Field>
          </div>

          {/* SEO params */}
          <div className="card" style={s.section}>
            <div className="section-title">Paramètres SEO</div>
            <div style={{ ...s.grid2, marginBottom: '12px' }}>
              <Field label="Mot-clé principal" required>
                <input value={form.keyword_main} onChange={handle('keyword_main')} placeholder="ex : pose de carrelage" />
              </Field>
              <Field label="Mots-clés secondaires" hint="Séparés par des virgules">
                <input value={form.keywords_sec} onChange={handle('keywords_sec')} placeholder="ex : carreleur, pose carrelage sol" />
              </Field>
            </div>
            {(form.keyword_main || secondaryTags.length > 0) && (
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px', marginBottom: '12px' }}>
                {form.keyword_main && (
                  <span className="badge badge-blue">★ {form.keyword_main}</span>
                )}
                {secondaryTags.map(t => (
                  <span key={t} className="badge badge-muted">{t}</span>
                ))}
              </div>
            )}
            <div style={{ ...s.grid2, marginBottom: '12px' }}>
              <Field label="Intention SEO / but de la page">
                <input value={form.intent} onChange={handle('intent')} placeholder="ex : Rassurer et convertir des particuliers..." />
              </Field>
              <Field label="H1 suggéré">
                <input value={form.h1} onChange={handle('h1')} placeholder="ex : Pose de carrelage à Pau" />
              </Field>
            </div>
            <div style={s.grid2}>
              <Field label="Nombre de mots">
                <select value={form.word_count} onChange={handle('word_count')}>
                  {WORD_COUNTS.map(w => <option key={w.value} value={w.value}>{w.label}</option>)}
                </select>
              </Field>
              <Field label="Langue">
                <select value={form.lang} onChange={handle('lang')}>
                  <option value="fr">Français</option>
                  <option value="en">Anglais</option>
                  <option value="es">Espagnol</option>
                </select>
              </Field>
            </div>
          </div>

          {/* E-commerce specific */}
          {branch === 'ecommerce' && (
            <div className="card fade-in" style={s.section}>
              <div className="section-title">Spécifique e-commerce</div>
              <div style={s.grid3}>
                <Field label="Nom du produit / catégorie">
                  <input value={form.product_name} onChange={handle('product_name')} placeholder="ex : Carrelage 60x60" />
                </Field>
                <Field label="Prix indicatif">
                  <input value={form.product_price} onChange={handle('product_price')} placeholder="ex : 15 € / m²" />
                </Field>
                <Field label="Référence interne">
                  <input value={form.product_ref} onChange={handle('product_ref')} placeholder="ex : SKU-001" />
                </Field>
              </div>
            </div>
          )}

          {/* Catalogue specific */}
          {branch === 'catalogue' && (
            <div className="card fade-in" style={s.section}>
              <div className="section-title">Spécifique catalogue</div>
              <div style={{ ...s.grid2, marginBottom: '12px' }}>
                <Field label="Nom du produit">
                  <input value={form.cat_product} onChange={handle('cat_product')} placeholder="ex : Dalle terrasse 20mm" />
                </Field>
                <Field label="Numéro de catalogue">
                  <input value={form.cat_ref} onChange={handle('cat_ref')} placeholder="ex : CAT-2025-047" />
                </Field>
              </div>
              <Field label="Caractéristiques techniques">
                <textarea value={form.cat_specs} onChange={handle('cat_specs')} placeholder="Dimensions, matière, résistance, finition..." style={{ minHeight: '60px' }} />
              </Field>
            </div>
          )}

          {/* Style */}
          <div className="card" style={s.section}>
            <div className="section-title">Style rédactionnel</div>
            <div style={{ ...s.grid2, marginBottom: '12px' }}>
              <Field label="Ton">
                <select value={form.tone} onChange={handle('tone')}>
                  {TONES.map(t => <option key={t.value} value={t.value}>{t.label}</option>)}
                </select>
              </Field>
              <div />
            </div>
            <Field label="Instructions supplémentaires">
              <textarea
                value={form.extra} onChange={handle('extra')}
                placeholder="Ex : éviter le mot 'innovant', mentionner l'agrément Anhydritec, inclure une FAQ de 4 questions..."
                style={{ minHeight: '70px' }}
              />
            </Field>
          </div>

          {/* Payload preview */}
          <div className="card" style={{ ...s.section, cursor: 'pointer' }} onClick={() => setShowPayload(p => !p)}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <span className="section-title" style={{ marginBottom: 0 }}>Aperçu du payload JSON</span>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="var(--text-muted)" strokeWidth="2"
                style={{ transform: showPayload ? 'rotate(180deg)' : 'none', transition: 'transform 0.2s' }}>
                <polyline points="6 9 12 15 18 9"/>
              </svg>
            </div>
            {showPayload && (
              <pre style={{
                fontFamily: 'var(--font-mono)', fontSize: '12px', color: 'var(--text-secondary)',
                background: 'var(--bg)', borderRadius: '8px', padding: '12px', marginTop: '12px',
                overflowX: 'auto', lineHeight: '1.5', maxHeight: '240px', overflowY: 'auto',
              }}>
                {JSON.stringify(buildPayload(), null, 2)}
              </pre>
            )}
          </div>

          {/* Alert */}
          {alert && (
            <div className="fade-in" style={{
              padding: '12px 14px', borderRadius: '8px', marginBottom: '12px', fontSize: '13px',
              background: alert.type === 'success' ? 'var(--success-soft)' : 'var(--danger-soft)',
              border: `1px solid ${alert.type === 'success' ? 'rgba(34,197,94,0.25)' : 'rgba(239,68,68,0.25)'}`,
              color: alert.type === 'success' ? 'var(--success)' : 'var(--danger)',
            }}>
              {alert.msg}
            </div>
          )}

          {/* Launch button */}
          <button
            onClick={launch}
            disabled={loading}
            style={{
              width: '100%', padding: '13px',
              background: loading ? 'rgba(108,99,255,0.4)' : 'var(--accent)',
              color: '#fff', borderRadius: '10px', fontWeight: '600', fontSize: '15px',
              display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '10px',
              transition: 'all 0.15s', cursor: loading ? 'not-allowed' : 'pointer',
              letterSpacing: '0.01em',
            }}
            onMouseEnter={e => { if (!loading) e.currentTarget.style.background = '#5a52e0' }}
            onMouseLeave={e => { if (!loading) e.currentTarget.style.background = 'var(--accent)' }}
          >
            {loading ? (
              <>
                <svg className="spin" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                  <path d="M21 12a9 9 0 1 1-6.219-8.56"/>
                </svg>
                Envoi en cours...
              </>
            ) : (
              <>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                  <path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/>
                </svg>
                Lancer l'automatisation Make
              </>
            )}
          </button>
        </div>
      </main>
    </div>
  )
}
