import './globals.css'

export const metadata = {
  title: 'H-TIC — Lanceur de contenu',
  description: 'Interface de génération de contenu automatisée',
}

export default function RootLayout({ children }) {
  return (
    <html lang="fr">
      <body>{children}</body>
    </html>
  )
}
