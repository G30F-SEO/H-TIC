import { NextResponse } from 'next/server'
import { verifySession, SESSION_KEY } from './lib/auth'

export async function middleware(request) {
  const { pathname } = request.nextUrl

  // Routes publiques
  if (pathname === '/' || pathname.startsWith('/api/auth')) {
    return NextResponse.next()
  }

  // API routes protégées (vérification dans les handlers)
  if (pathname.startsWith('/api/')) {
    return NextResponse.next()
  }

  // Pages protégées : vérifier le cookie
  const token = request.cookies.get(SESSION_KEY)?.value
  if (!token || !(await verifySession(token))) {
    return NextResponse.redirect(new URL('/', request.url))
  }

  return NextResponse.next()
}

export const config = {
  matcher: ['/((?!_next/static|_next/image|favicon.ico).*)'],
}
